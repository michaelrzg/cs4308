// Michael Rizig
// Term: Fall 2024
// Instructor: Gayler
// Assignment 8
// File: ValuePair.h
// 11/24/24
//  this file contains the value pairs structure header
#ifndef ValuePair_H
#define ValuePair_H

#include <string.h>
typedef struct ValuePair{
    char* value;
    int count;
} ValuePair;
#endif
